"""Run local repository integrity and contract checks without model/web calls."""
from pathlib import Path
import hashlib
import os
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]

def main():
    failures=[]
    checksums=ROOT/'SHA256SUMS.txt'
    if checksums.exists():
        for line in checksums.read_text().splitlines():
            digest,relative=line.split('  ',1)
            p=(ROOT/relative).resolve()
            if not p.is_relative_to(ROOT) or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
                failures.append('checksum: '+relative)
    else:failures.append('missing SHA256SUMS.txt')
    if failures:
        print('FAIL: '+'; '.join(failures));return 1
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    full=ROOT/'game-classification'
    tutorial=ROOT/'tutorial/game-classification-draft'
    with tempfile.TemporaryDirectory(prefix='game-skill-check-') as folder:
        commands=[
            (full,[sys.executable,'scripts/taxonomy.py','--check']),
            (full,[sys.executable,'-m','unittest','discover','-s','scripts','-p','test_*.py','-v']),
            (full,[sys.executable,'scripts/validate_results.py','--input','examples/input.csv','--results','examples/results.json','--report',str(Path(folder)/'historical_qc.json')]),
            (tutorial,[sys.executable,'scripts/check_result.py','--input','examples/input.json','--taxonomy','references/taxonomy-excerpt.json','--result','examples/result.expected.json']),
            (tutorial,[sys.executable,'-m','unittest','discover','-s','scripts','-p','test_*.py','-v']),
            (tutorial,[sys.executable,'scripts/run_demo.py'])
        ]
        for cwd,argv in commands:
            result=subprocess.run(argv,cwd=cwd,env=env,text=True,capture_output=True)
            print(result.stdout,end='');print(result.stderr,end='')
            if result.returncode:return result.returncode
    print('PASS: file integrity and behavior checks. No new model classification or accuracy evaluation.')
    return 0

if __name__=='__main__':raise SystemExit(main())
