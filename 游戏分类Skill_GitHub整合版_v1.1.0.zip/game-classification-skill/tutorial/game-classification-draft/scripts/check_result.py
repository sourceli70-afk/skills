#!/usr/bin/env python3
"""只检查格式、记录完整性、身份门槛和逐字引文；不判断分类语义。"""

import argparse
import json
import sys
from collections import Counter
from pathlib import Path
from urllib.parse import urlsplit


class CheckError(ValueError):
    pass


ROOT = Path(__file__).resolve().parents[1]

STATES = {"CLASSIFIED_DRAFT", "IDENTITY_UNRESOLVED",
          "EVIDENCE_INSUFFICIENT", "UNATTEMPTED"}
RESULT_FIELDS = {"record_id", "state", "game_type_l1", "game_type_l2",
                 "evidence_id", "evidence_fact", "rationale", "next_action"}


def require(condition, message):
    if not condition:
        raise CheckError(message)


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def http_url(value):
    if not nonempty(value) or any(c.isspace() or ord(c) < 32 for c in value):
        return False
    try:
        parsed = urlsplit(value)
        return (parsed.scheme in {"http", "https"} and bool(parsed.hostname)
                and (parsed.port is None or 0 < parsed.port <= 65535))
    except ValueError:
        return False


def object_with(value, fields, where, exact=False):
    require(isinstance(value, dict), where + " 必须是对象")
    missing = set(fields) - set(value)
    extra = set(value) - set(fields) if exact else set()
    require(not missing and not extra,
            where + " 字段不符合要求（缺少：" + ", ".join(sorted(missing))
            + "；多出：" + ", ".join(sorted(map(str, extra))) + "）")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "JSON 存在重复键：" + repr(key))
        result[key] = value
    return result


def reject_constant(value):
    raise CheckError("JSON 不允许常量 " + value)


def load_json(path, label):
    try:
        with Path(path).open(encoding="utf-8") as handle:
            return json.load(handle, object_pairs_hook=unique_object,
                             parse_constant=reject_constant)
    except CheckError as error:
        raise CheckError(label + "文件：" + str(error)) from None
    except json.JSONDecodeError as error:
        raise CheckError("{}文件 JSON 无效（第 {} 行，第 {} 列）".format(
            label, error.lineno, error.colno)) from None
    except (OSError, UnicodeError, ValueError) as error:
        raise CheckError(label + "文件无法读取：" + str(error)) from None


def check(input_data, taxonomy, result_data):
    """通过时返回状态计数；未执行或其他结构错误抛出 CheckError。"""
    object_with(taxonomy, {"version", "classes"}, "词典")
    require(nonempty(taxonomy["version"]), "词典 version 必须是非空字符串")
    require(isinstance(taxonomy["classes"], list), "词典 classes 必须是数组")
    classes = {}
    for index, item in enumerate(taxonomy["classes"], 1):
        where = "词典第 {} 类".format(index)
        object_with(item, {"l1", "l2", "definition", "include_conditions",
                           "exclude_conditions"}, where)
        for field in ("l1", "l2", "definition"):
            require(nonempty(item[field]), where + " " + field + " 必须是非空字符串")
        for field in ("include_conditions", "exclude_conditions"):
            require(isinstance(item[field], list)
                    and all(nonempty(v) for v in item[field]),
                    where + " " + field + " 必须是非空字符串组成的数组（可为空）")
        require(item["l2"] not in classes, "词典 l2 重复：" + item["l2"])
        classes[item["l2"]] = item["l1"]

    require(isinstance(input_data, list) and bool(input_data), "输入必须是非空数组")
    records, materials, owners = {}, {}, {}
    for index, record in enumerate(input_data, 1):
        where = "输入第 {} 条".format(index)
        object_with(record, {"record_id", "game_name", "scope", "identity_confirmed",
                             "is_fictional", "identity_note", "product_url", "materials"}, where)
        for field in ("record_id", "game_name", "scope", "identity_note"):
            require(nonempty(record[field]), where + " " + field + " 必须是非空字符串")
        record_id = record["record_id"]
        where = "输入 " + record_id
        require(record_id not in records, "输入 record_id 重复：" + record_id)
        for field in ("identity_confirmed", "is_fictional"):
            require(type(record[field]) is bool, where + " " + field + " 必须是布尔值")
        require(record["product_url"] is None or isinstance(record["product_url"], str),
                where + " product_url 必须是字符串或 null")
        if record["identity_confirmed"] and not record["is_fictional"]:
            require(http_url(record["product_url"]), where + " 已确认的真实记录须有有效 http(s) product_url")
        require(isinstance(record["materials"], list), where + " materials 必须是数组")
        materials[record_id] = {}
        for material in record["materials"]:
            object_with(material, {"evidence_id", "text_kind", "text", "sources"}, where + " 材料")
            evidence_id = material["evidence_id"]
            require(nonempty(evidence_id), where + " evidence_id 必须是非空字符串")
            require(evidence_id not in owners, "材料 evidence_id 重复或跨记录复用：" + evidence_id)
            require(isinstance(material["text_kind"], str) and material["text_kind"] in ("official_summary", "fictional"),
                    where + " text_kind 非法")
            require(nonempty(material["text"]), where + " 材料 text 必须是非空字符串")
            require(isinstance(material["sources"], list), where + " sources 必须是数组")
            require(record["is_fictional"] or bool(material["sources"]), where + " 真实材料须至少有一项来源")
            for source in material["sources"]:
                object_with(source, {"title", "url"}, where + " 来源")
                require(nonempty(source["title"]) and http_url(source["url"]),
                        where + " 来源须有非空 title 和有效 http(s) url")
            materials[record_id][evidence_id] = material["text"]
            owners[evidence_id] = record_id
        records[record_id] = record

    require(isinstance(result_data, list), "结果必须是数组")
    counts, seen = Counter(), set()
    for index, result in enumerate(result_data, 1):
        where = "结果第 {} 条".format(index)
        object_with(result, RESULT_FIELDS, where, exact=True)
        record_id = result["record_id"]
        require(nonempty(record_id), where + " record_id 必须是非空字符串")
        require(record_id not in seen, "结果 record_id 重复：" + record_id)
        require(record_id in records, "结果含额外 record_id：" + record_id)
        seen.add(record_id)
        where = "结果 " + record_id
        state = result["state"]
        require(isinstance(state, str) and state in STATES, where + " state 非法")
        confirmed = records[record_id]["identity_confirmed"]
        require(confirmed or state in {"IDENTITY_UNRESOLVED", "UNATTEMPTED"},
                where + " 身份未确认，只能为 IDENTITY_UNRESOLVED 或 UNATTEMPTED")
        require(not confirmed or state != "IDENTITY_UNRESOLVED",
                where + " 身份已确认，不能为 IDENTITY_UNRESOLVED")
        require(nonempty(result["rationale"]), where + " rationale 必须是非空字符串")
        require(isinstance(result["next_action"], str), where + " next_action 必须是字符串")
        if state == "CLASSIFIED_DRAFT":
            l1, l2 = result["game_type_l1"], result["game_type_l2"]
            require(isinstance(l2, str) and l2 in classes, where + " 二级标签不在词典中")
            require(isinstance(l1, str) and l1 == classes[l2], where + " 一级标签非法或与二级标签父子关系不符")
            require(nonempty(result["evidence_id"]), where + " 分类草稿必须引用本记录的材料")
        else:
            require(result["game_type_l1"] is None and result["game_type_l2"] is None,
                    where + " 未决或未执行记录的两级标签必须为 null")
            require(nonempty(result["next_action"]), where + " 未决或未执行记录须有非空 next_action")
        evidence_id, fact = result["evidence_id"], result["evidence_fact"]
        require(isinstance(fact, str), where + " evidence_fact 必须是字符串")
        if evidence_id is None:
            require(fact == "", where + " 无引用时 evidence_fact 必须为空字符串")
        else:
            require(nonempty(evidence_id), where + " evidence_id 必须是非空字符串或 null")
            require(evidence_id in materials[record_id], where + " evidence_id 不属于本记录的材料")
            require(nonempty(fact) and fact in materials[record_id][evidence_id],
                    where + " evidence_fact 必须是所引材料中非空、原样连续的子串")
        counts[state] += 1
    missing = set(records) - seen
    require(not missing, "结果缺少 record_id：" + ", ".join(sorted(missing)))
    require(not counts["UNATTEMPTED"], "未执行记录 {} 条（UNATTEMPTED），整批不通过".format(counts["UNATTEMPTED"]))
    return counts


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default=ROOT / "examples/input.json", help="输入 JSON；默认随包输入，显式相对路径按当前工作目录")
    parser.add_argument("--taxonomy", default=ROOT / "references/taxonomy-excerpt.json", help="词典 JSON；默认随包词典，显式相对路径按当前工作目录")
    parser.add_argument("--result", required=True, help="待检查的结果 JSON；相对当前工作目录")
    args = parser.parse_args(argv)
    try:
        counts = check(load_json(args.input, "输入"), load_json(args.taxonomy, "词典"),
                       load_json(args.result, "结果"))
    except CheckError as error:
        print("检查未通过：" + str(error), file=sys.stderr)
        return 1
    print("检查通过：分类草稿 {} 条，身份未确认 {} 条，证据不足 {} 条。格式检查不代表语义正确。".format(
        counts["CLASSIFIED_DRAFT"], counts["IDENTITY_UNRESOLVED"], counts["EVIDENCE_INSUFFICIENT"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
