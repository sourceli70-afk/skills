"""Behavior checks for the supplied tutorial contract; not game accuracy tests."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from check_result import ROOT, CheckError, check, load_json

class TutorialChecks(unittest.TestCase):
    def setUp(self):
        self.inputs=load_json(ROOT/'examples/input.json','input')
        self.taxonomy=load_json(ROOT/'references/taxonomy-excerpt.json','taxonomy')
        self.results=load_json(ROOT/'examples/result.expected.json','result')
    def validate(self):return check(self.inputs,self.taxonomy,self.results)
    def reject(self):
        with self.assertRaises(CheckError):self.validate()
    def test_reference_and_unresolved(self):
        self.assertEqual(dict(self.validate()),{'CLASSIFIED_DRAFT':3,'IDENTITY_UNRESOLVED':1,'EVIDENCE_INSUFFICIENT':1})
    def test_empty_job_is_rejected(self):self.inputs=[];self.results=[];self.reject()
    def test_duplicate_input_id(self):self.inputs.append(copy.deepcopy(self.inputs[0]));self.reject()
    def test_missing_result(self):self.results.pop();self.reject()
    def test_extra_result(self):
        r=copy.deepcopy(self.results[0]);r['record_id']='unknown';self.results.append(r);self.reject()
    def test_cross_record_evidence(self):self.results[0]['evidence_id']='brief-C';self.reject()
    def test_noncontiguous_quote(self):self.results[0]['evidence_fact']='这不是输入摘要的原句';self.reject()
    def test_parent_mismatch(self):self.results[0]['game_type_l1']='射击';self.reject()
    def test_unknown_label(self):self.results[0]['game_type_l2']='新增而未定义的类';self.reject()
    def test_unconfirmed_product_cannot_be_classified(self):self.inputs[0]['identity_confirmed']=False;self.reject()
    def test_confirmed_identity_cannot_be_unresolved(self):
        self.results[0].update(state='IDENTITY_UNRESOLVED',game_type_l1=None,game_type_l2=None,next_action='补身份');self.reject()
    def test_unresolved_requires_action(self):self.results[3]['next_action']='';self.reject()
    def test_unattempted_is_not_completed(self):
        self.results[3]['state']='UNATTEMPTED';self.reject()
    def test_exact_output_contract(self):self.results[0]['extra']='unexpected';self.reject()
    def test_bad_material_kind_reports_contract_error(self):
        self.inputs[0]['materials'][0]['text_kind']=[];self.reject()
    def test_duplicate_json_key_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'bad.json';p.write_text('{"a":1,"a":2}')
            with self.assertRaises(CheckError):load_json(p,'fixture')
    def test_nonfinite_json_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'bad.json';p.write_text('{"a":NaN}')
            with self.assertRaises(CheckError):load_json(p,'fixture')
    def test_structurally_valid_wrong_reason_is_not_detected(self):
        self.results[0].update(game_type_l1='卡牌对局',game_type_l2='CCG/TCG',rationale='有跃迁复刻，因此是卡牌对局。')
        self.assertEqual(self.validate()['CLASSIFIED_DRAFT'],3)

if __name__=='__main__':unittest.main()
