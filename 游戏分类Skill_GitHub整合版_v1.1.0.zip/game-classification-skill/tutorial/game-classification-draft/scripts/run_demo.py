"""Demonstrate checks with prepared data; this does not invoke a model."""
import copy
import json
from check_result import ROOT, CheckError, check, load_json

def main():
    inputs=load_json(ROOT/'examples/input.json','input')
    taxonomy=load_json(ROOT/'references/taxonomy-excerpt.json','taxonomy')
    reference=load_json(ROOT/'examples/result.expected.json','result')
    cases=[]
    for name, mutate, expected in [
        ('reference',lambda rows:None,True),
        ('missing_record',lambda rows:rows.pop(),False),
        ('parent_mismatch',lambda rows:rows[0].update(game_type_l1='射击'),False),
        ('wrong_quote',lambda rows:rows[0].update(evidence_fact='未提供的句子'),False),
        ('cross_record_source',lambda rows:rows[0].update(evidence_id='brief-C'),False),
        ('unattempted',lambda rows:rows[3].update(state='UNATTEMPTED'),False),
        ('wrong_semantics_still_structurally_valid',lambda rows:rows[0].update(game_type_l1='卡牌对局',game_type_l2='CCG/TCG',rationale='有跃迁复刻，因此是卡牌对局。'),True),
    ]:
        rows=copy.deepcopy(reference);mutate(rows)
        try:check(inputs,taxonomy,rows);passed=True
        except CheckError:passed=False
        cases.append({'case':name,'contract_passed':passed,'expected':expected})
    ok=all(x['contract_passed']==x['expected'] for x in cases)
    print(json.dumps({'status':'PASS' if ok else 'FAIL','cases':cases,'model_execution':'NOT_RUN','classification_accuracy':'NOT_EVALUATED'},ensure_ascii=False,indent=2))
    return 0 if ok else 1

if __name__=='__main__':raise SystemExit(main())
