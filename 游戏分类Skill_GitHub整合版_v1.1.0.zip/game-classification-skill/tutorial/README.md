# 游戏分类 Skill 示例包

**整合版 v1.1.0 · 2026-10-22**

这个包配合《如何写一个有用的 Skill？用游戏分类案例做一遍》使用，帮助你看清“材料—规则—结果—检查”怎样接起来。

包含三个真实游戏案例和两条虚构材料，词典只覆盖这些案例涉及的三个分类组合。它适合学习和修改；处理其他游戏时，要先确认词表是否覆盖，再补充相应定义与判断条件。

先想直接使用完整词典处理其他游戏，请返回 [仓库首页](../README.md)。本目录专门用于学习给定材料的判断。

## 从哪里开始

**只想看案例：**打开《分类案例.md》，查看资料、分类与理由。

**想自己运行：**用支持读取和保存本地文件的 AI 工具打开 `game-classification-draft` 文件夹，先不要打开参考答案。直接发送：

> 请读取本目录的 SKILL.md、references/taxonomy-excerpt.json 和 examples/input.json，逐条处理 A—E，将 JSON 列表保存到 output/my-result.json。只使用给定材料，不联网补全；不要读取 examples/result.expected.json 或上级目录的《分类案例.md》。不要修改输入、词典或检查器。保存后运行 scripts/check_result.py，展示检查输出，并说明未决项需要补什么。

这条练习不要求安装 Skill，也不用配置单独的 API 密钥；分类仍由你所用的 AI 工具执行。检查脚本需要 Python 3.10 或以上，只使用标准库。

在 `game-classification-draft` 文件夹内，检查命令为：

```bash
python3 scripts/check_result.py --input examples/input.json --result output/my-result.json
```

若电脑上的 Python 命令叫 `python`，将 `python3` 换成 `python`。运行前先确认版本满足要求。

保存自己的结果后，再打开 `examples/result.expected.json` 对照。分类、未决原因和关键事实应对应；理由的措辞不必完全相同。

## 文件分别做什么

| 文件 | 用途 |
| --- | --- |
| game-classification-draft/SKILL.md | 读取顺序、判断步骤、输出与检查要求 |
| references/taxonomy-excerpt.json | 一级定义、二级定义和判断边界 |
| examples/input.json | 五条输入，保留身份、范围、资料摘要及来源 |
| examples/result.expected.json | 教学参考输出 |
| scripts/check_result.py | 检查记录、字段、标签关系和材料引用 |
| agents/openai.yaml | 支持该格式的客户端所用的展示信息 |

表中除第一项外的路径，均相对 `game-classification-draft` 文件夹。

## 改成自己的练习

复制 `examples/input.json` 为 `examples/my-input.json`，替换产品、范围和材料；不要只改游戏名而保留原玩法资料。真实产品的身份与来源要核实，`identity_confirmed` 不是供程序自动核实身份的开关。

如果改了输入，运行时明确指定新文件，检查时也要同步：

```bash
python3 scripts/check_result.py --input examples/my-input.json --result output/my-result.json
```

补充词典时，同步写清定义、适用条件与排除条件，并加入有区分度的案例。不要只添加一个新标签名称。

## 怎样看检查结果

合理的“身份未确认”或“资料不足”可以通过检查；`UNATTEMPTED` 表示还没处理，整批不能算完成。检查器能发现漏行、非法标签、父子关系与引用错误，但不能判断分类理由是否符合事实。即使程序通过，仍要看证据是否足够。

A—C 的输入是根据官方资料整理的中文摘要，附链接与核对位置，不是官方逐字引文；D—E 为虚构。参考输出是教学示范，不是独立准确率评测。本教程目录只包含精简词典；完整词典位于仓库根目录的 game-classification。这里不提供历史批量结果。


## 检查器的边界演示

在 game-classification-draft 目录运行 `python3 scripts/run_demo.py`，可以看到漏行、父子类错误、错误引文、跨记录引用和未执行项的检查结果，以及一个结构合法但判断理由错误仍然通过的反例。该脚本只使用预置资料，不调用模型。
