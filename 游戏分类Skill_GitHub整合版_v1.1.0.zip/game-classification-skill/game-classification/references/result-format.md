# 读者版结果格式

输入 CSV 至少有唯一的 `record_id` 和 `game_name`，可加 `product_url`、`platform`、`notes`。普通名称列表由执行 AI 先整理成 CSV，每条原始输入保留一行。示例清单见 `examples/input.csv`；同目录的 results 文件是一次公开资料示范，不作为后续分类的固定答案。

结果为 JSON 数组。每个对象必须包含下列字段：

| 字段 | 形式与要求 |
| --- | --- |
| record_id、input_name | 对应输入 ID 与原始名称，不遗漏、不重复 |
| canonical_name、product_url | 已确认产品的规范名与产品链接；无法确认时可为 null |
| identity_status | CONFIRMED / UNRESOLVED / NON_GAME |
| status | CLASSIFIED / EVIDENCE_INSUFFICIENT / IDENTITY_UNRESOLVED / NON_GAME / FAILED / UNATTEMPTED |
| game_type_l1、game_type_l2 | 词典原值；未确定玩法分类时为 JSON null |
| core_loop_summary | 主要操作、推进条件和挑战的简洁事实摘要，未完成时可为空 |
| classification_rationale、nearest_alternative | 为什么支持当前类别、最近相邻候选及关键区别；CLASSIFIED 时均非空 |
| sources | 下述来源对象数组；空列表不等于查过但没有 |
| identity_evidence_ids、classification_evidence_ids | 对应 sources.id 的数组；身份已确认、分类已确定时分别必须非空 |
| mechanics_supported | `[{"tag":"受控机制名","evidence_ids":["S1"]}]`，只保存有正证据的子集 |
| mechanic_review_complete | 固定 JSON false，本包不提供完整 129 项审阅结论 |
| facets | 按结构字段名保存 `{"value":"枚举原值","evidence_ids":["S1"]}`；未审字段省略 |
| content | 形式同 facets；单选 value 为字符串，多选为数组；未审字段省略 |
| next_action | 未决／失败填写具体下一步；已分类但其他字段缺资料也可说明 |

sources 每项包含 `id`、`reference`、`locator`、`facts`、`kind`、`inspected`。reference 是实际使用的 http(s) URL 或用户文件位置；locator 指明段落、页码或图片位置；facts 是非空事实字符串列表。kind 为 TEXT、USER_FILE 或 VISUAL。VISUAL 只能在真正看过素材后写 inspected=true；其他 kind 写 false。

身份明确但玩法资料不足时使用 identity_status=CONFIRMED、status=EVIDENCE_INSUFFICIENT，L1/L2 为空；独立取得证据的内容字段仍可保留。身份未决或 NON_GAME 时，所有分类、机制、结构、内容标签留空。FAILED 保留真实原因，UNATTEMPTED 不计为已经处理。附加 `issues`、`candidates` 等说明字段可以保留。

标签名称严格按 JSON 词典填写，包括斜杠和空格。`待核验` 不写入确定值；用 null、未决状态或省略未审字段表达。多选空数组只有明确审阅依据时才作为结论使用。

检查器核对记录、受控值、父子关系、必需结构、来源引用和视觉观察标记，不联网验证来源、也不判断事实是否充分支持分类。报告始终说明 semantic_accuracy=NOT_EVALUATED。CSV 便于查看，完整来源和各字段引用关系保存在 JSON。
