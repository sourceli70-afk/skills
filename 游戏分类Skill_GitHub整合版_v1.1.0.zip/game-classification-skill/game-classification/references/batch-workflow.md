# 批量与恢复

较大清单或可能跨会话的任务，在输出目录保存输入、checkpoint.json、run_manifest.json 和结果。少量游戏可以直接逐条产出 JSON。

以下命令中的输入输出换成实际路径；以 Skill 根目录为工作目录。模型名称或参数不可见时如实写 UNAVAILABLE_NOT_RECORDED，不猜测。

```bash
python3 scripts/batch_checkpoint.py init --input input.csv --id-column record_id --checkpoint output/checkpoint.json --manifest output/run_manifest.json --skill-dir . --skill-version reader-1.0.1 --run-id run-001
python3 scripts/batch_checkpoint.py resume --checkpoint output/checkpoint.json --manifest output/run_manifest.json
```

处理一条输入，先把该条完整结果保存成单个 JSON 对象文件，再记录状态。只有实际读取并判断以后才能 record；不能先把所有记录改成 COMPLETED。

```bash
python3 scripts/batch_checkpoint.py record --checkpoint output/checkpoint.json --manifest output/run_manifest.json --record-id G001 --state COMPLETED --sources-checked official_store --result-file output/G001.json
```

结果 status=CLASSIFIED 对应 checkpoint 的 COMPLETED；NON_GAME 也是已完成的判断，但结果里不带游戏标签。证据不足、身份未决、失败分别使用同名 checkpoint 状态，并提供 `--reason`；来源实际打不开时可另记 `--source-failures-json`。

```bash
python3 scripts/batch_checkpoint.py record --checkpoint output/checkpoint.json --manifest output/run_manifest.json --record-id G004 --state IDENTITY_UNRESOLVED --reason "同名产品尚未确定，请补开发商或产品链接" --result-file output/G004.json
python3 scripts/batch_checkpoint.py export --checkpoint output/checkpoint.json --output output/checkpoint-export.csv
```

export 是恢复与审计表，含 result_json，不能把它直接当成扁平分类表。收集各记录的结果对象组成 results.json，随后运行 `validate_results.py` 输出结果 CSV 和 QC。

恢复先检查原输入 SHA，输入变更或要修改已记录的终态时新建运行。已完成记录不可覆盖；旧结果用于追溯。总量等于已尝试加未执行，但“所有记录都尝试过”不等于全部成功分类。检查器和完成计数不产生来源事实，也不保证语义正确。
