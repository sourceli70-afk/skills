#!/usr/bin/env python3
"""Initialize, resume, and audit an immutable per-record labeling checkpoint.

This utility manages execution state only. It does not classify games or create
evidence, and therefore cannot turn a queued record into an attempted record.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path

STATES = {"UNATTEMPTED", "COMPLETED", "EVIDENCE_INSUFFICIENT", "IDENTITY_UNRESOLVED", "FAILED"}
TERMINAL = STATES - {"UNATTEMPTED"}
RESULT_STATES = {"CLASSIFIED": "COMPLETED", "NON_GAME": "COMPLETED",
                 "EVIDENCE_INSUFFICIENT": "EVIDENCE_INSUFFICIENT",
                 "IDENTITY_UNRESOLVED": "IDENTITY_UNRESOLVED", "FAILED": "FAILED"}


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def file_sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def stable_tree_sha(root: Path) -> str:
    h = hashlib.sha256()
    excluded = {"__pycache__", ".git", "run"}
    for path in sorted(p for p in root.rglob("*") if p.is_file() and not (set(p.relative_to(root).parts) & excluded)):
        rel = path.relative_to(root).as_posix()
        h.update(rel.encode("utf-8")); h.update(b"\0"); h.update(bytes.fromhex(file_sha(path)))
    return h.hexdigest()


def read_input(path: Path, id_column: str) -> tuple[list[dict], list[str]]:
    with path.open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fields = list(reader.fieldnames or [])
        if len(fields) != len(set(fields)):
            raise ValueError("input contains duplicate headers")
        if id_column not in fields:
            raise ValueError(f"input is missing ID column {id_column!r}")
        rows = list(reader)
    if any(None in row or any(v is None for v in row.values()) for row in rows):
        raise ValueError("input contains nonrectangular rows")
    ids = [str(r.get(id_column) or "").strip() for r in rows]
    if not rows or any(not x for x in ids):
        raise ValueError("input must have rows and every row must have a non-empty ID")
    if len(ids) != len(set(ids)):
        raise ValueError("input contains duplicate IDs")
    return rows, fields


def atomic_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n"); f.flush(); os.fsync(f.fileno())
        os.replace(temp_name, path)
    except Exception:
        Path(temp_name).unlink(missing_ok=True)
        raise


def counts(data: dict) -> dict[str, int]:
    states = [r["batch_state"] for r in data["records"]]
    return {
        "total_count": len(states),
        "attempted_count": sum(s in TERMINAL for s in states),
        "completed_count": states.count("COMPLETED"),
        "evidence_insufficient_count": states.count("EVIDENCE_INSUFFICIENT"),
        "identity_unresolved_count": states.count("IDENTITY_UNRESOLVED"),
        "failed_count": states.count("FAILED"),
        "unattempted_count": states.count("UNATTEMPTED"),
        "source_access_failure_count": sum(int(r.get("source_access_failure_count", 0)) for r in data["records"]),
    }


def same_path(left: Path, right: Path) -> bool:
    return left.resolve() == right.resolve() or (left.exists() and right.exists() and left.samefile(right))


def validate_result(result, record_id: str, state: str) -> None:
    if result is None and state != "COMPLETED":
        return
    if not isinstance(result, dict) or not result:
        raise ValueError("COMPLETED requires a non-empty JSON result object" if state == "COMPLETED"
                         else "result must be a non-empty JSON object")
    if result.get("record_id") != record_id:
        raise ValueError("result requires record_id matching the checkpoint row")
    if not isinstance(result.get("status"), str) or RESULT_STATES.get(result["status"]) != state:
        raise ValueError("result requires status matching the checkpoint state")


def load(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("schema_version") != "label-batch-checkpoint-v1":
        raise ValueError("unsupported checkpoint schema")
    if any(not isinstance(data.get(key), str) or not data[key]
           for key in ("checkpoint_path", "manifest_path", "run_id")):
        raise ValueError("checkpoint lacks run/path binding; preserve it and initialize a new run in separate files")
    if Path(data["checkpoint_path"]).resolve() != path.resolve():
        raise ValueError("checkpoint path does not match its run binding")
    protected = [path, Path(data["input_path"]), Path(data["manifest_path"])]
    if any(same_path(a, b) for i, a in enumerate(protected) for b in protected[i + 1:]):
        raise ValueError("input, checkpoint and manifest must be separate files")
    for record in data["records"]:
        validate_result(record["result"], record["record_id"], record["batch_state"])
    actual = counts(data)
    if actual != data.get("counts"):
        raise ValueError("checkpoint count summary is stale or corrupt")
    return data


def load_run(checkpoint: Path, manifest: Path) -> tuple[dict, dict]:
    if same_path(checkpoint, manifest):
        raise ValueError("checkpoint and manifest must be separate files")
    data = load(checkpoint)
    if manifest != Path(data["manifest_path"]).resolve():
        raise ValueError("manifest path does not match checkpoint run binding")
    run = json.loads(manifest.read_text(encoding="utf-8"))
    if not isinstance(run, dict) or run.get("schema_version") != "label-batch-run-manifest-v1":
        raise ValueError("unsupported run manifest schema")
    for key, expected in (("run_id", data["run_id"]), ("checkpoint_path", str(checkpoint)),
                          ("input_path", data["input_path"]), ("input_sha256", data["input_sha256"]),
                          ("started_at", data["created_at"])):
        if run.get(key) != expected:
            raise ValueError(f"manifest {key} does not match checkpoint run binding")
    if file_sha(Path(data["input_path"])) != data["input_sha256"]:
        raise ValueError("input hash changed; start a new run rather than using changed data")
    return data, run


def cmd_init(args) -> int:
    input_path = Path(args.input).resolve()
    checkpoint = Path(args.checkpoint).resolve()
    manifest = Path(args.manifest).resolve()
    if len({input_path, checkpoint, manifest}) != 3:
        raise ValueError("input, checkpoint and manifest must be separate files")
    if checkpoint.exists() or manifest.exists():
        raise ValueError("checkpoint or manifest exists; refusing to overwrite")
    if not args.run_id.strip():
        raise ValueError("run ID must be non-empty")
    rows, fields = read_input(input_path, args.id_column)
    root = Path(args.skill_dir).resolve()
    vocabulary = root / "references" / "taxonomy-controlled-vocabulary.json"
    data = {
        "schema_version": "label-batch-checkpoint-v1",
        "created_at": now(),
        "run_id": args.run_id,
        "checkpoint_path": str(checkpoint),
        "manifest_path": str(manifest),
        "input_path": str(input_path),
        "input_sha256": file_sha(input_path),
        "id_column": args.id_column,
        "input_fields": fields,
        "records": [{"record_id": str(row[args.id_column]).strip(), "input": row, "batch_state": "UNATTEMPTED",
                     "attempted_at": None, "result": None, "review_reason": None,
                     "sources_checked": [], "source_access_failures": [], "source_access_failure_count": 0}
                    for row in rows],
        "model": args.model or "UNAVAILABLE_NOT_RECORDED",
        "reasoning": args.reasoning or "UNAVAILABLE_NOT_RECORDED",
        "sampling_parameters": args.sampling_parameters or "UNAVAILABLE_NOT_RECORDED",
        "counts": {},
    }
    data["counts"] = counts(data)
    atomic_json(checkpoint, data)
    manifest_data = {
        "schema_version": "label-batch-run-manifest-v1", "run_id": args.run_id,
        "skill_version": args.skill_version, "skill_tree_sha256": stable_tree_sha(root),
        "taxonomy_sha256": file_sha(vocabulary), "input_path": str(input_path),
        "input_sha256": data["input_sha256"], "checkpoint_path": str(checkpoint),
        "started_at": data["created_at"], "ended_at": None, "model": data["model"],
        "reasoning": data["reasoning"], "sampling_parameters": data["sampling_parameters"],
        "source_types_used": [], "source_access_failures": [], **data["counts"],
        "completion_status": "IN_PROGRESS",
    }
    atomic_json(manifest, manifest_data)
    print(json.dumps({"status": "PASS", "counts": data["counts"], "checkpoint": str(checkpoint), "manifest": str(manifest)}, ensure_ascii=False))
    return 0


def cmd_resume(args) -> int:
    checkpoint, manifest = Path(args.checkpoint).resolve(), Path(args.manifest).resolve()
    data, _ = load_run(checkpoint, manifest)
    remaining = [r["record_id"] for r in data["records"] if r["batch_state"] == "UNATTEMPTED"]
    print(json.dumps({"status": "RESUMABLE" if remaining else "ALL_ATTEMPTED", "counts": data["counts"], "pending_record_ids": remaining}, ensure_ascii=False))
    return 0


def cmd_record(args) -> int:
    checkpoint, manifest = Path(args.checkpoint).resolve(), Path(args.manifest).resolve()
    data, run = load_run(checkpoint, manifest)
    if args.state not in TERMINAL:
        raise ValueError(f"record state must be terminal: {sorted(TERMINAL)}")
    if args.state != "COMPLETED" and not args.reason:
        raise ValueError("non-COMPLETED outcomes require --reason")
    if args.state != "IDENTITY_UNRESOLVED" and args.state != "FAILED" and not args.sources_checked:
        raise ValueError("classification outcomes require at least one --sources-checked value")
    by_id = {r["record_id"]: r for r in data["records"]}
    if args.record_id not in by_id:
        raise ValueError(f"unknown record_id {args.record_id!r}")
    record = by_id[args.record_id]
    if record["batch_state"] != "UNATTEMPTED":
        raise ValueError("record is already terminal; completed work is immutable and will not be overwritten")
    result_file = getattr(args, "result_file", None)
    result = json.loads(Path(result_file).read_text(encoding="utf-8")) if result_file else (json.loads(args.result_json) if args.result_json else None)
    validate_result(result, args.record_id, args.state)
    failures = json.loads(args.source_failures_json) if args.source_failures_json else []
    if not isinstance(failures, list) or any(not isinstance(x, str) for x in failures):
        raise ValueError("--source-failures-json must be a JSON array of strings")
    record.update({"batch_state": args.state, "attempted_at": now(), "result": result,
                   "review_reason": args.reason, "sources_checked": args.sources_checked or [],
                   "source_access_failures": failures, "source_access_failure_count": len(failures)})
    data["counts"] = counts(data)
    atomic_json(checkpoint, data)
    run.update(data["counts"])
    run["source_access_failures"] = [
        {"record_id": r["record_id"], "failures": r["source_access_failures"]}
        for r in data["records"] if r["source_access_failures"]
    ]
    run["source_types_used"] = sorted({s for r in data["records"] for s in r["sources_checked"]})
    run["completion_status"] = "COMPLETE_ALL_ATTEMPTED" if data["counts"]["unattempted_count"] == 0 else "IN_PROGRESS"
    run["ended_at"] = now() if data["counts"]["unattempted_count"] == 0 else None
    atomic_json(manifest, run)
    print(json.dumps({"status": "RECORDED", "record_id": args.record_id, "counts": data["counts"]}, ensure_ascii=False))
    return 0


def cmd_export(args) -> int:
    data = load(Path(args.checkpoint).resolve())
    out = Path(args.output).resolve(); out.parent.mkdir(parents=True, exist_ok=True)
    protected = [Path(args.checkpoint).resolve(), Path(data["input_path"]).resolve(),
                 Path(data["manifest_path"]).resolve()]
    if any(same_path(out, p) for p in protected):
        raise ValueError("export must not overwrite checkpoint, input or manifest")
    control_columns = ["record_id", "batch_state", "attempted_at", "review_reason", "sources_checked", "source_access_failures", "result_json"]
    # Input data is user-owned and may itself contain names such as batch_state
    # or result_json. Duplicate CSV headers are ambiguous (DictReader silently
    # keeps the last value), so preserve the authoritative checkpoint fields and
    # namespace only colliding input columns.
    input_column_map = {}
    used_columns = set(control_columns) | set(data["input_fields"])
    for name in data["input_fields"]:
        target = name
        if name in control_columns:
            target = f"input_{name}"
            while target in used_columns:
                target = f"input_{target}"
        input_column_map[name] = target
        used_columns.add(target)
    columns = control_columns + list(input_column_map.values())
    with out.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for r in data["records"]:
            row = {"record_id": r["record_id"], "batch_state": r["batch_state"], "attempted_at": r["attempted_at"] or "",
                   "review_reason": r["review_reason"] or "", "sources_checked": "|".join(r["sources_checked"]),
                   "source_access_failures": "|".join(r["source_access_failures"]),
                   "result_json": json.dumps(r["result"], ensure_ascii=False, sort_keys=True) if r["result"] is not None else ""}
            for name, value in r["input"].items():
                row[input_column_map[name]] = value
            writer.writerow(row)
    print(json.dumps({"status": "PASS", "counts": data["counts"], "output": str(out)}, ensure_ascii=False))
    return 0


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init"); init.add_argument("--input", required=True); init.add_argument("--checkpoint", required=True); init.add_argument("--manifest", required=True)
    init.add_argument("--id-column", required=True); init.add_argument("--skill-dir", required=True); init.add_argument("--skill-version", required=True)
    init.add_argument("--run-id", required=True); init.add_argument("--model"); init.add_argument("--reasoning"); init.add_argument("--sampling-parameters")
    init.set_defaults(func=cmd_init)
    resume = sub.add_parser("resume"); resume.add_argument("--checkpoint", required=True); resume.add_argument("--manifest", required=True); resume.set_defaults(func=cmd_resume)
    rec = sub.add_parser("record"); rec.add_argument("--checkpoint", required=True); rec.add_argument("--manifest", required=True); rec.add_argument("--record-id", required=True)
    rec.add_argument("--state", required=True, choices=sorted(TERMINAL)); rec.add_argument("--reason"); rec.add_argument("--sources-checked", action="append", default=[])
    result = rec.add_mutually_exclusive_group()
    result.add_argument("--result-json"); result.add_argument("--result-file")
    rec.add_argument("--source-failures-json"); rec.set_defaults(func=cmd_record)
    exp = sub.add_parser("export"); exp.add_argument("--checkpoint", required=True); exp.add_argument("--output", required=True); exp.set_defaults(func=cmd_export)
    return p


def main() -> int:
    args = parser().parse_args()
    try:
        return args.func(args)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
