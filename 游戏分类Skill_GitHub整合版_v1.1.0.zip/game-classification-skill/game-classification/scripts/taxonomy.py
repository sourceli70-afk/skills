#!/usr/bin/env python3
"""Inspect the bundled taxonomy; this script does not classify games."""
import argparse
import hashlib
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def load():
    return json.loads((ROOT / 'references/taxonomy-controlled-vocabulary.json').read_text(encoding='utf-8'))

def mechanisms(v):
    return {name: definition for group in v['mechanic_tags'].values() for name, definition in group.items()}

def check():
    v = load()
    counts = [len(v['game_type_l1']), len(v['game_type_l2']), len(mechanisms(v))]
    problems = []
    if counts != [17, 87, 129]:
        problems.append('taxonomy count mismatch')
    for label, definition in v['game_type_l2'].items():
        if definition['parent_l1'] not in v['game_type_l1']:
            problems.append('unknown parent: ' + label)
    release = json.loads((ROOT / 'release.json').read_text(encoding='utf-8'))
    for entry in release['source_files']:
        if entry['source_relative_path'].startswith('references/'):
            p = ROOT / entry['source_relative_path']
            expected = entry.get('reader_sha256')
            if not expected:
                problems.append('missing reader reference hash: ' + p.name)
            elif hashlib.sha256(p.read_bytes()).hexdigest() != expected:
                problems.append('reader reference changed: ' + p.name)
    return {'status': 'FAIL' if problems else 'PASS', 'counts': dict(zip(['L1', 'L2', 'mechanics'], counts)), 'errors': problems}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument('--label'); g.add_argument('--parent-l1'); g.add_argument('--search'); g.add_argument('--summary', action='store_true'); g.add_argument('--check', action='store_true')
    args = p.parse_args(); v = load()
    if args.check:
        out = check()
    elif args.summary:
        out = {parent: [label for label, d in v['game_type_l2'].items() if d['parent_l1'] == parent] for parent in v['game_type_l1']}
    elif args.parent_l1:
        out = {label: d for label, d in v['game_type_l2'].items() if d['parent_l1'] == args.parent_l1}
    else:
        entries = []
        for axis in ['game_type_l1', 'game_type_l2']:
            entries.extend({'axis': axis, 'label': k, 'definition': d} for k, d in v[axis].items())
        entries.extend({'axis': 'mechanic', 'label': k, 'definition': d} for k, d in mechanisms(v).items())
        for axis, definitions in {**v['structured_dimension_definitions'], **v['content_dimension_definitions']}.items():
            entries.extend({'axis': axis, 'label': k, 'definition': d} for k, d in definitions.items())
        out = [e for e in entries if e['label'] == args.label] if args.label else [e for e in entries if args.search.casefold() in json.dumps(e, ensure_ascii=False).casefold()]
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 1 if not out or (isinstance(out, dict) and out.get('status') == 'FAIL') else 0

if __name__ == '__main__':
    raise SystemExit(main())
