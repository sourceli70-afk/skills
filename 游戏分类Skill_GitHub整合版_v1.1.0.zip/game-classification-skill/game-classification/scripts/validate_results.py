#!/usr/bin/env python3
"""Validate structure and provenance references, not semantic classification accuracy."""
import argparse
import csv
import json
from collections import Counter
from pathlib import Path
from taxonomy import load, mechanisms, check

REQUIRED = set('record_id input_name canonical_name product_url identity_status status game_type_l1 game_type_l2 core_loop_summary classification_rationale nearest_alternative sources identity_evidence_ids classification_evidence_ids mechanics_supported mechanic_review_complete facets content next_action'.split())
STATES = {'CLASSIFIED', 'EVIDENCE_INSUFFICIENT', 'IDENTITY_UNRESOLVED', 'NON_GAME', 'FAILED', 'UNATTEMPTED'}

def nonempty(x):
    return isinstance(x, str) and bool(x.strip())

def read_input(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f); fields = reader.fieldnames or []
        if len(fields) != len(set(fields)) or not {'record_id', 'game_name'} <= set(fields):
            raise ValueError('input needs unique headers including record_id and game_name')
        rows = list(reader)
    if not rows or any(None in r or any(v is None for v in r.values()) for r in rows):
        raise ValueError('input is empty or has nonrectangular rows')
    ids = [r['record_id'] for r in rows]
    if any(not nonempty(i) or i != i.strip() for i in ids) or len(ids) != len(set(ids)):
        raise ValueError('input IDs must be nonempty, trimmed and unique')
    if any(not nonempty(r['game_name']) for r in rows):
        raise ValueError('input game_name cannot be empty')
    return rows

def validate(inputs, results, vocabulary=None):
    v = vocabulary or load(); errors = []; warnings = []
    expected = {r['record_id']: r['game_name'] for r in inputs}; seen = []
    mechs = mechanisms(v)
    def err(rid, msg): errors.append({'record_id': rid, 'error': msg})
    if not isinstance(results, list):
        return {'status': 'FAIL', 'semantic_accuracy': 'NOT_EVALUATED', 'errors': [{'error': 'results must be a JSON array'}]}
    for pos, r in enumerate(results):
        rid = r.get('record_id') if isinstance(r, dict) else None
        if not isinstance(rid, str):
            err(str(pos), 'row must be object with string record_id'); continue
        seen.append(rid)
        missing = sorted(REQUIRED - r.keys())
        if missing:
            err(rid, 'missing fields: ' + ', '.join(missing)); continue
        if rid not in expected or r['input_name'] != expected.get(rid):
            err(rid, 'input ID/name mismatch')
        state, identity = r['status'], r['identity_status']
        if not isinstance(state, str) or state not in STATES: err(rid, 'unknown status')
        if not isinstance(identity, str) or identity not in {'CONFIRMED', 'UNRESOLVED', 'NON_GAME'}: err(rid, 'unknown identity_status')
        if state == 'UNATTEMPTED': err(rid, 'unattempted input cannot pass final QC')
        allowed = {'CLASSIFIED': {'CONFIRMED'}, 'EVIDENCE_INSUFFICIENT': {'CONFIRMED'}, 'IDENTITY_UNRESOLVED': {'UNRESOLVED'}, 'NON_GAME': {'NON_GAME'}, 'FAILED': {'UNRESOLVED', 'CONFIRMED'}, 'UNATTEMPTED': {'UNRESOLVED'}}
        if isinstance(state, str) and state in allowed and identity not in allowed[state]: err(rid, 'identity and result status conflict')
        for key in ['core_loop_summary', 'classification_rationale', 'nearest_alternative', 'next_action']:
            if not isinstance(r[key], str): err(rid, key + ' must be string')
        for key in ['canonical_name', 'product_url']:
            if r[key] is not None and not nonempty(r[key]): err(rid, key + ' must be nonempty string or null')
        if state != 'CLASSIFIED' and not nonempty(r['next_action']): err(rid, 'unfinished/excluded outcome needs next_action')
        if r['mechanic_review_complete'] is not False: err(rid, 'reader edition supports positive mechanisms only; complete must be false')
        sources = r['sources']; source_map = {}
        if not isinstance(sources, list):
            err(rid, 'sources must be array'); sources = []
        for s in sources:
            if not isinstance(s, dict) or not nonempty(s.get('id')):
                err(rid, 'source needs string id'); continue
            sid = s['id']
            if sid in source_map: err(rid, 'duplicate source id: ' + sid)
            source_map[sid] = s
            if not all(nonempty(s.get(k)) for k in ['reference', 'locator']): err(rid, 'source needs reference and locator: ' + sid)
            facts = s.get('facts')
            if not isinstance(facts, list) or not facts or any(not nonempty(f) for f in facts): err(rid, 'source needs concrete facts: ' + sid)
            if s.get('kind') not in ('TEXT', 'USER_FILE', 'VISUAL'): err(rid, 'invalid source kind: ' + sid)
            if s.get('kind') == 'VISUAL':
                if s.get('inspected') is not True: err(rid, 'visual source must have actually been inspected: ' + sid)
            elif s.get('inspected') is not False: err(rid, 'nonvisual source inspected must be false: ' + sid)
        def refs(value, field, needed=False, visual=False):
            if not isinstance(value, list) or any(not nonempty(x) for x in value):
                err(rid, field + ': expected array of source IDs'); return
            if len(value) != len(set(value)): err(rid, field + ': duplicate source references')
            if needed and not value: err(rid, field + ': evidence required')
            if any(x not in source_map for x in value): err(rid, field + ': unknown source reference')
            if visual and not any(source_map.get(x, {}).get('kind') == 'VISUAL' and source_map.get(x, {}).get('inspected') is True for x in value):
                err(rid, field + ': inspected visual evidence required')
        refs(r['identity_evidence_ids'], 'identity_evidence_ids', identity in ('CONFIRMED', 'NON_GAME'))
        refs(r['classification_evidence_ids'], 'classification_evidence_ids', state == 'CLASSIFIED')
        if identity == 'CONFIRMED' and not all(nonempty(r[k]) for k in ['canonical_name', 'product_url']): err(rid, 'confirmed identity needs product name and URL')
        l1, l2 = r['game_type_l1'], r['game_type_l2']
        d = v['game_type_l2'].get(l2, {}) if isinstance(l2, str) else {}
        if state == 'CLASSIFIED':
            if not isinstance(l1, str) or l1 not in v['game_type_l1'] or not d: err(rid, 'unknown L1/L2')
            elif d['parent_l1'] != l1: err(rid, 'L1/L2 parent mismatch')
            if not all(nonempty(r[k]) for k in ['core_loop_summary', 'classification_rationale', 'nearest_alternative']): err(rid, 'classified result needs core loop, rationale and alternative')
        elif l1 is not None or l2 is not None: err(rid, 'unclassified result must have null L1/L2')
        if identity != 'CONFIRMED' and any([l1 is not None, l2 is not None, r['mechanics_supported'], r['facets'], r['content']]): err(rid, 'unresolved/non-game identity must not carry labels')
        supported = r['mechanics_supported']; tags = []
        if not isinstance(supported, list): err(rid, 'mechanics_supported must be array'); supported = []
        for m in supported:
            if not isinstance(m, dict) or not isinstance(m.get('tag'), str): err(rid, 'malformed mechanism'); continue
            tags.append(m['tag'])
            if m['tag'] not in mechs: err(rid, 'unknown mechanism: ' + m['tag'])
            refs(m.get('evidence_ids'), 'mechanic ' + m['tag'], True)
        if len(tags) != len(set(tags)): err(rid, 'duplicate mechanisms')
        for container in ['facets', 'content']:
            fields = r[container]
            if not isinstance(fields, dict): err(rid, container + ' must be object'); continue
            for field, item in fields.items():
                definitions = v['structured_dimensions'] if container == 'facets' else v['content_dimensions']
                if field not in definitions: err(rid, 'unknown ' + container + ' field: ' + field); continue
                if not isinstance(item, dict): err(rid, field + ': expected value/evidence_ids object'); continue
                spec = definitions[field]; multi = container == 'content' and spec['multi']
                values = item.get('value') if multi else [item.get('value')]
                allowed_values = spec['values'] if container == 'content' else spec
                if not isinstance(values, list) or any(not isinstance(x, str) or x == '待核验' or x not in allowed_values for x in values): err(rid, field + ': invalid controlled value')
                elif len(values) != len(set(values)): err(rid, field + ': duplicate values')
                refs(item.get('evidence_ids'), field, True, field in ['art_style_primary', 'visual_presentation_tags'])
        facets = r['facets'] if isinstance(r['facets'], dict) else {}
        for field, values in d.get('facet_required', {}).items():
            item = facets.get(field)
            if not isinstance(item, dict) or item.get('value') not in values: err(rid, 'required L2 facet missing/incompatible: ' + field)
        for field, values in d.get('facet_forbidden', {}).items():
            item = facets.get(field)
            if isinstance(item, dict) and item.get('value') in values: err(rid, 'forbidden L2 facet: ' + field)
        if state in ('FAILED', 'EVIDENCE_INSUFFICIENT', 'IDENTITY_UNRESOLVED'): warnings.append({'record_id': rid, 'status': state})
    for rid, n in Counter(seen).items():
        if n != 1: err(rid, 'duplicate output record')
    for rid in sorted(set(expected) - set(seen)): err(rid, 'missing output record')
    states = Counter(r.get('status') for r in results if isinstance(r, dict) and isinstance(r.get('status'), str))
    return {'status': 'FAIL' if errors else 'PASS', 'semantic_accuracy': 'NOT_EVALUATED', 'input_count': len(inputs), 'result_count': len(results), 'status_counts': dict(states), 'errors': errors, 'warnings': warnings, 'limits': 'Only structure, controlled values, record coverage and evidence references were checked. No website contents or semantic correctness were verified.'}

def export_csv(path, results):
    cols = ['record_id', 'input_name', 'canonical_name', 'product_url', 'identity_status', 'status', 'game_type_l1', 'game_type_l2', 'core_loop_summary', 'classification_rationale', 'nearest_alternative', 'mechanics_supported', 'facets', 'content', 'next_action']
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=cols); writer.writeheader()
        for r in results:
            row = {k: r[k] for k in cols}
            for k in ['mechanics_supported', 'facets', 'content']: row[k] = json.dumps(row[k], ensure_ascii=False)
            writer.writerow(row)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', required=True); p.add_argument('--results', required=True); p.add_argument('--report', required=True); p.add_argument('--csv')
    a = p.parse_args()
    paths = [Path(x).resolve() for x in [a.input, a.results, a.report] + ([a.csv] if a.csv else [])]
    if len(set(paths)) != len(paths) or any(x.exists() and y.exists() and x.samefile(y) for i, x in enumerate(paths) for y in paths[i+1:]):
        p.error('input, results, report and CSV must be separate files')
    try:
        frozen = check()
        if frozen['status'] != 'PASS': raise ValueError('bundled taxonomy integrity failed: ' + str(frozen['errors']))
        inputs = read_input(a.input); results = json.loads(paths[1].read_text(encoding='utf-8'))
        report = validate(inputs, results)
    except (OSError, ValueError, TypeError) as e:
        report = {'status': 'FAIL', 'semantic_accuracy': 'NOT_EVALUATED', 'errors': [{'error': str(e)}]}
    paths[2].parent.mkdir(parents=True, exist_ok=True); paths[2].write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    if report['status'] == 'PASS' and a.csv:
        paths[3].parent.mkdir(parents=True, exist_ok=True); export_csv(paths[3], results)
    print(json.dumps(report, ensure_ascii=False)); return 0 if report['status'] == 'PASS' else 2

if __name__ == '__main__': raise SystemExit(main())
