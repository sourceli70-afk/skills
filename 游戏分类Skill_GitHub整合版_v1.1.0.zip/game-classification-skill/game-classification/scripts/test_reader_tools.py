"""Behavior checks for the reader contract. Synthetic fixtures are not accuracy tests."""
import copy
import csv
import json
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path
from taxonomy import ROOT, check
from validate_results import validate, read_input

INPUTS = [{'record_id': 'A', 'game_name': '虚构测试样本'}]
BASE = dict(record_id='A', input_name='虚构测试样本', canonical_name='虚构测试样本', product_url='fixture://A', identity_status='CONFIRMED', status='CLASSIFIED', game_type_l1='益智', game_type_l2='逻辑/空间解谜', core_loop_summary='仅用于测试：通过空间约束解题推进。', classification_rationale='仅用于测试：逻辑解谜为主要推进条件。', nearest_alternative='仅用于测试：平台跳跃不主导。', sources=[dict(id='S1', reference='fixture://A', locator='test fixture', facts=['虚构测试数据，不是真实游戏证据。'], kind='USER_FILE', inspected=False)], identity_evidence_ids=['S1'], classification_evidence_ids=['S1'], mechanics_supported=[], mechanic_review_complete=False, facets={}, content={}, next_action='')

class ReaderTests(unittest.TestCase):
    def setUp(self): self.row = copy.deepcopy(BASE)
    def run_qc(self): return validate(INPUTS, [self.row])
    def assert_bad(self): self.assertEqual(self.run_qc()['status'], 'FAIL')
    def test_frozen_dictionary(self): self.assertEqual(check()['status'], 'PASS')
    def temporary_reference_check(self, edit):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            release = json.loads((ROOT/'release.json').read_text())
            for entry in release['source_files']:
                relative = entry['source_relative_path']
                if relative.startswith('references/'):
                    p = root/relative; p.parent.mkdir(parents=True, exist_ok=True)
                    p.write_bytes((ROOT/relative).read_bytes())
            edit(root, release)
            (root/'release.json').write_text(json.dumps(release))
            with patch('taxonomy.ROOT', root):
                return check()
    def test_source_provenance_is_not_reader_checksum(self):
        def edit(root, release):
            for entry in release['source_files']:
                entry['source_sha256'] = '0'*64
        self.assertEqual(self.temporary_reference_check(edit)['status'], 'PASS')
    def test_reader_reference_tampering_rejected(self):
        def edit(root, release):
            p = root/'references/taxonomy-controlled-vocabulary.json'
            p.write_bytes(p.read_bytes()+b'\n')
        self.assertEqual(self.temporary_reference_check(edit)['status'], 'FAIL')
    def test_missing_reader_hash_rejected(self):
        def edit(root, release):
            del release['source_files'][0]['reader_sha256']
        self.assertEqual(self.temporary_reference_check(edit)['status'], 'FAIL')
    def test_minimal_good(self): self.assertEqual(self.run_qc()['status'], 'PASS')
    def test_parent_mismatch(self): self.row['game_type_l1'] = '射击'; self.assert_bad()
    def test_unknown_mechanism(self): self.row['mechanics_supported'] = [{'tag': '随便造的标签', 'evidence_ids': ['S1']}]; self.assert_bad()
    def test_missing_evidence(self): self.row['classification_evidence_ids'] = ['S2']; self.assert_bad()
    def test_identity_not_confirmed(self): self.row['identity_status'] = 'UNRESOLVED'; self.assert_bad()
    def test_visual_requires_observation(self): self.row['content'] = {'art_style_primary': {'value': '像素风', 'evidence_ids': ['S1']}}; self.assert_bad()
    def test_no_fake_full_mechanic_review(self): self.row['mechanic_review_complete'] = True; self.assert_bad()
    def test_l2_required_facet(self): self.row.update(game_type_l1='RPG', game_type_l2='ARPG'); self.assert_bad()
    def test_required_facet_satisfied(self):
        self.row.update(game_type_l1='RPG', game_type_l2='ARPG', facets={'combat_system': {'value': '实时动作', 'evidence_ids': ['S1']}})
        self.assertEqual(self.run_qc()['status'], 'PASS')
    def test_unknown_genre_can_have_independent_theme(self):
        self.row.update(status='EVIDENCE_INSUFFICIENT', game_type_l1=None, game_type_l2=None, classification_evidence_ids=[], content={'theme_primary': {'value': '科幻', 'evidence_ids': ['S1']}}, next_action='补充玩法资料')
        self.assertEqual(self.run_qc()['status'], 'PASS')
    def test_missing_row(self): self.assertEqual(validate(INPUTS, [])['status'], 'FAIL')
    def test_duplicate_row(self): self.assertEqual(validate(INPUTS, [self.row, self.row])['status'], 'FAIL')
    def test_unattempted_fails_final(self):
        self.row.update(status='UNATTEMPTED', identity_status='UNRESOLVED', game_type_l1=None, game_type_l2=None, next_action='尚未执行'); self.assert_bad()
    def test_duplicate_input_headers_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/'input.csv'; p.write_text('record_id,game_name,game_name\nA,甲,乙\n')
            with self.assertRaises(ValueError): read_input(p)
    def test_nonrectangular_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/'input.csv'; p.write_text('record_id,game_name\nA,甲,乙\n')
            with self.assertRaises(ValueError): read_input(p)
    def test_checkpoint_nested_collision_and_result_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp); inp = d/'input.csv'; cp=d/'checkpoint.json'; manifest=d/'manifest.json'
            inp.write_text('record_id,game_name,input_record_id,batch_state,input_batch_state\nA,虚构测试样本,old,UNATTEMPTED,older\n')
            def call(*args):
                p = subprocess.run([sys.executable, str(ROOT/'scripts/batch_checkpoint.py'), *map(str, args)], capture_output=True, text=True)
                self.assertEqual(p.returncode, 0, p.stdout+p.stderr)
            call('init', '--input', inp, '--id-column', 'record_id', '--checkpoint', cp, '--manifest', manifest, '--skill-dir', ROOT, '--skill-version', 'test', '--run-id', 'test')
            result=d/'row.json'; result.write_text(json.dumps(self.row,ensure_ascii=False))
            call('record', '--checkpoint', cp, '--manifest', manifest, '--record-id', 'A', '--state', 'COMPLETED', '--sources-checked', 'fixture', '--result-file', result)
            out=d/'export.csv'; call('export', '--checkpoint', cp, '--output', out)
            with out.open(encoding='utf-8-sig') as f:
                r=csv.DictReader(f); headers=r.fieldnames; row=next(r)
            self.assertEqual(len(headers), len(set(headers))); self.assertEqual(row['batch_state'], 'COMPLETED'); self.assertEqual(row['input_batch_state'], 'older'); self.assertEqual(row['input_input_batch_state'], 'UNATTEMPTED')
    def test_cli_refuses_input_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'input.csv'; p.write_text('record_id,game_name\nA,甲\n'); before=p.read_bytes()
            proc=subprocess.run([sys.executable,str(ROOT/'scripts/validate_results.py'),'--input',str(p),'--results',str(p),'--report',str(p)],capture_output=True)
            self.assertNotEqual(proc.returncode,0); self.assertEqual(before,p.read_bytes())

if __name__ == '__main__': unittest.main()
