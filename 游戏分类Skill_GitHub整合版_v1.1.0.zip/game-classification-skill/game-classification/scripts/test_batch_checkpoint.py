import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).with_name("batch_checkpoint.py")
SKILL = SCRIPT.parents[1]


class BatchCheckpointTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.input = self.root / "input.csv"
        with self.input.open("w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["game_key", "canonical_game_name"])
            w.writeheader(); w.writerows([
                {"game_key": "g1", "canonical_game_name": "Game 1"},
                {"game_key": "g2", "canonical_game_name": "Game 2"},
            ])
        self.checkpoint = self.root / "checkpoint.json"
        self.manifest = self.root / "manifest.json"

    def tearDown(self): self.tmp.cleanup()

    def run_cli(self, *args, expected=0):
        p = subprocess.run([sys.executable, str(SCRIPT), *map(str, args)], capture_output=True, text=True)
        self.assertEqual(p.returncode, expected, p.stdout + p.stderr)
        return json.loads(p.stdout)

    def init(self):
        return self.run_cli("init", "--input", self.input, "--checkpoint", self.checkpoint,
                            "--manifest", self.manifest, "--id-column", "game_key", "--skill-dir", SKILL,
                            "--skill-version", "V12.2.16", "--run-id", "test-run")

    def test_init_resume_and_immutable_checkpoint(self):
        initialized = self.init()
        self.assertEqual(initialized["counts"]["unattempted_count"], 2)
        self.assertEqual(self.run_cli("resume", "--checkpoint", self.checkpoint, "--manifest", self.manifest)["status"], "RESUMABLE")
        recorded = self.run_cli("record", "--checkpoint", self.checkpoint, "--manifest", self.manifest,
                                "--record-id", "g1", "--state", "EVIDENCE_INSUFFICIENT", "--reason", "官方页未说明玩法",
                                "--sources-checked", "official_store")
        self.assertEqual(recorded["counts"]["attempted_count"], 1)
        self.assertEqual(recorded["counts"]["evidence_insufficient_count"], 1)
        self.run_cli("record", "--checkpoint", self.checkpoint, "--manifest", self.manifest,
                     "--record-id", "g1", "--state", "COMPLETED", "--result-json", '{"game_type_l1":"RPG"}',
                     expected=2)

    def test_all_attempted_updates_manifest_and_export(self):
        self.init()
        for key in ("g1", "g2"):
            self.run_cli("record", "--checkpoint", self.checkpoint, "--manifest", self.manifest,
                         "--record-id", key, "--state", "COMPLETED", "--sources-checked", "official_store",
                         "--result-json", json.dumps({"record_id": key, "status": "CLASSIFIED", "game_type_l1": "RPG"}))
        run = json.loads(self.manifest.read_text())
        self.assertEqual(run["completion_status"], "COMPLETE_ALL_ATTEMPTED")
        self.assertEqual(run["attempted_count"], run["total_count"])
        self.assertEqual(run["unattempted_count"], 0)
        exported = self.root / "out.csv"
        result = self.run_cli("export", "--checkpoint", self.checkpoint, "--output", exported)
        self.assertEqual(result["counts"]["completed_count"], 2)
        with exported.open(encoding="utf-8-sig", newline="") as f:
            self.assertEqual(len(list(csv.DictReader(f))), 2)

    def test_changed_input_hash_prevents_resume(self):
        self.init()
        with self.input.open("a", encoding="utf-8") as f: f.write("g3,Game 3\n")
        self.run_cli("resume", "--checkpoint", self.checkpoint, "--manifest", self.manifest, expected=2)

    def test_export_namespaces_input_fields_that_collide_with_checkpoint_columns(self):
        colliding = self.root / "colliding.csv"
        fields = ["game_key", "canonical_game_name", "batch_state", "attempted_at", "review_reason", "sources_checked", "result_json"]
        with colliding.open("w", encoding="utf-8", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
            w.writerow({"game_key": "g1", "canonical_game_name": "Game 1", "batch_state": "UNATTEMPTED",
                        "attempted_at": "historical-time", "review_reason": "old note", "sources_checked": "old source",
                        "result_json": '{"old":true}'})
        cp, mf, out = self.root / "collision-checkpoint.json", self.root / "collision-manifest.json", self.root / "collision-out.csv"
        self.run_cli("init", "--input", colliding, "--checkpoint", cp, "--manifest", mf,
                     "--id-column", "game_key", "--skill-dir", SKILL, "--skill-version", "V12.2.16",
                     "--run-id", "collision-run")
        self.run_cli("record", "--checkpoint", cp, "--manifest", mf, "--record-id", "g1",
                     "--state", "COMPLETED", "--sources-checked", "https://example.test/source",
                     "--result-json", json.dumps({"record_id": "g1", "status": "CLASSIFIED", "game_type_l1": "RPG"}))
        self.run_cli("export", "--checkpoint", cp, "--output", out)
        with out.open(encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f); rows = list(reader)
        self.assertEqual(len(reader.fieldnames), len(set(reader.fieldnames)))
        self.assertEqual(rows[0]["batch_state"], "COMPLETED")
        self.assertEqual(rows[0]["input_batch_state"], "UNATTEMPTED")
        self.assertEqual(rows[0]["input_attempted_at"], "historical-time")
        self.assertEqual(rows[0]["input_review_reason"], "old note")
        self.assertEqual(rows[0]["input_sources_checked"], "old source")
        self.assertEqual(json.loads(rows[0]["result_json"]), {"record_id": "g1", "status": "CLASSIFIED", "game_type_l1": "RPG"})
        self.assertEqual(json.loads(rows[0]["input_result_json"]), {"old": True})


    def assert_unchanged(self, checkpoint_before, manifest_before):
        self.assertEqual(self.checkpoint.read_bytes(), checkpoint_before)
        self.assertEqual(self.manifest.read_bytes(), manifest_before)

    def test_same_or_missing_manifest_is_rejected_without_writes(self):
        self.init()
        cp, mf = self.checkpoint.read_bytes(), self.manifest.read_bytes()
        for wrong in (self.checkpoint, self.root / "missing.json"):
            for command in ("resume", "record"):
                args = [command, "--checkpoint", self.checkpoint, "--manifest", wrong]
                if command == "record":
                    args += ["--record-id", "g1", "--state", "COMPLETED", "--sources-checked", "fixture",
                             "--result-json", '{"record_id":"g1","status":"CLASSIFIED"}']
                self.run_cli(*args, expected=2)
                self.assert_unchanged(cp, mf)

    def test_foreign_manifest_is_rejected_without_writes(self):
        self.init()
        foreign_cp, foreign_mf = self.root / "other-cp.json", self.root / "other-mf.json"
        self.run_cli("init", "--input", self.input, "--checkpoint", foreign_cp, "--manifest", foreign_mf,
                     "--id-column", "game_key", "--skill-dir", SKILL, "--skill-version", "test", "--run-id", "other")
        before = {p: p.read_bytes() for p in (self.checkpoint, self.manifest, foreign_cp, foreign_mf)}
        self.run_cli("resume", "--checkpoint", self.checkpoint, "--manifest", foreign_mf, expected=2)
        self.run_cli("record", "--checkpoint", self.checkpoint, "--manifest", foreign_mf,
                     "--record-id", "g1", "--state", "COMPLETED", "--sources-checked", "fixture",
                     "--result-json", '{"record_id":"g1","status":"CLASSIFIED"}', expected=2)
        for p, content in before.items(): self.assertEqual(p.read_bytes(), content)

    def test_tampered_manifest_binding_is_rejected(self):
        self.init()
        original = self.manifest.read_text()
        cp = self.checkpoint.read_bytes()
        for field in ("run_id", "checkpoint_path", "input_sha256"):
            data = json.loads(original); data[field] = "wrong"
            self.manifest.write_text(json.dumps(data))
            self.run_cli("resume", "--checkpoint", self.checkpoint, "--manifest", self.manifest, expected=2)
            self.assertEqual(self.checkpoint.read_bytes(), cp)
        self.manifest.write_text(original)
        self.assertEqual(self.run_cli("resume", "--checkpoint", self.checkpoint, "--manifest", self.manifest)["status"], "RESUMABLE")

    def test_export_cannot_overwrite_manifest_or_hardlink(self):
        import os
        self.init()
        cp, mf = self.checkpoint.read_bytes(), self.manifest.read_bytes()
        alias = self.root / "manifest-alias.json"
        os.link(self.manifest, alias)
        for output in (self.manifest, alias):
            self.run_cli("export", "--checkpoint", self.checkpoint, "--output", output, expected=2)
            self.assert_unchanged(cp, mf)

    def test_invalid_completed_result_does_not_lock_record(self):
        self.init()
        cp, mf = self.checkpoint.read_bytes(), self.manifest.read_bytes()
        bad = [None, "null", "{}", '{"status":"CLASSIFIED"}', '{"record_id":"g1"}',
               '{"record_id":"other","status":"CLASSIFIED"}', '{"record_id":"g1","status":"FAILED"}']
        for result in bad:
            args = ["record", "--checkpoint", self.checkpoint, "--manifest", self.manifest,
                    "--record-id", "g1", "--state", "COMPLETED", "--sources-checked", "fixture"]
            if result is not None: args += ["--result-json", result]
            self.run_cli(*args, expected=2)
            self.assert_unchanged(cp, mf)
        self.run_cli("record", "--checkpoint", self.checkpoint, "--manifest", self.manifest,
                     "--record-id", "g1", "--state", "COMPLETED", "--sources-checked", "fixture",
                     "--result-json", '{"record_id":"g1","status":"CLASSIFIED"}')
        self.assertEqual(json.loads(self.checkpoint.read_text())["counts"]["completed_count"], 1)

    def test_legacy_unbound_checkpoint_is_rejected(self):
        self.init()
        data = json.loads(self.checkpoint.read_text())
        data.pop("manifest_path")
        self.checkpoint.write_text(json.dumps(data))
        cp, mf = self.checkpoint.read_bytes(), self.manifest.read_bytes()
        self.run_cli("resume", "--checkpoint", self.checkpoint, "--manifest", self.manifest, expected=2)
        self.assert_unchanged(cp, mf)


if __name__ == "__main__": unittest.main()
